package main

func add(a, b int) int {
	return a + b
}

func sub(a, b int) int {
	return a - b
}
